# Complete Meal Planning Guide for Lactose Intolerant Teenagers in New Zealand

## Quick Reference Shopping List

### Essential Weekly Items from PAK'nSAVE (Most Cost-Effective)

**Lactose-Free Dairy Alternatives**
- Anchor Zero Lacto Blue Milk (1L) - $4.97
- Vitasoy Unsweetened Coconut Milk (1L) - $3.59
- Angel Food Dairy-Free Cheese Block (220g) - $7.99

**Gluten-Free Bread & Grains**
- Pams Gluten Free Everyday Loaf (500g) - $7.99
- Rice cakes - $3-4/pack
- Corn tortillas - $3-5/pack
- Quinoa - $4-6/kg

**Protein Sources**
- Canned tuna - $2-3/can
- Free-range eggs (dozen) - $6-8
- Mixed nuts and seeds - $8-12/kg
- Chickpeas/legumes - $2-3/can

## 2-Week Rotating Meal Plan

### Week 1 Lunches
- **Monday**: Tuna and avocado on GF bread with cucumber
- **Tuesday**: Chicken wrap in corn tortilla with dairy-free cheese
- **Wednesday**: Quinoa salad bowl with roast vegetables
- **Thursday**: Leftover pasta with meat sauce (dairy-free)
- **Friday**: Bento box with GF crackers, hard cheese, apple slices

### Week 2 Lunches
- **Monday**: Salmon and salad on GF bread
- **Tuesday**: Rice paper rolls with ham and vegetables
- **Wednesday**: Brown rice bowl with chicken and edamame
- **Thursday**: Egg salad sandwich on GF bread
- **Friday**: Thermos soup with GF roll

### Daily Snack Rotation
**Morning Tea Options** (rotate weekly):
- Hard boiled eggs (2) with rice crackers
- Apple slices with almond butter
- Rice cakes with avocado
- Mixed nuts and seeds (30g portion)
- Homemade bliss balls

**Afternoon Snack Options**:
- Carrot and cucumber sticks with hummus
- Banana with seed butter
- Cherry tomatoes with dairy-free cheese cubes
- Homemade trail mix
- Rice crackers with hummus

## Batch Cooking & Prep Ideas (Weekend)

### Sunday Meal Prep (2 hours)
1. **Cook quinoa in bulk** - use for salads all week
2. **Hard boil 6-8 eggs** - quick protein for snacks/lunches
3. **Prepare hummus** - cheaper homemade, lasts 5 days
4. **Make bliss balls** - energy snacks for the week
5. **Wash and chop vegetables** - ready for quick assembly
6. **Cook a large pasta sauce** - use for lunches and dinners

### Make-Ahead Freezer Items
- Soup portions in containers
- Cooked meatballs (dairy-free)
- Pancakes or muffins (GF/DF)
- Smoothie packs (pre-portioned frozen fruit)

## Budget Breakdown & Cost Saving

### Weekly Budget: $100
- Lactose-free alternatives: $15
- Gluten-free bread products: $12  
- Protein sources: $20
- Fresh produce: $18
- Healthy snacks: $10
- Pantry staples: $8
- Breakfast items: $12
- Emergency items: $5

### Money-Saving Strategies
1. **Shop PAK'nSAVE first** - 15-20% cheaper than competitors
2. **Buy seasonal produce** - 30-40% savings
3. **Use store brands** - Pams products are reliable and cheaper
4. **Batch cook** - saves time and reduces food waste
5. **Check weekly specials** online before shopping
6. **Buy bulk non-perishables** when on special

## Nutritional Considerations for Growing Teens

### Daily Requirements (Age 15)
- **Calcium**: 1300mg (critical for bone development)
- **Protein**: 1-2g per kg body weight
- **Iron**: 15mg for girls, 11mg for boys
- **Energy**: 2000-2500 calories depending on activity level

### Calcium-Rich Alternatives to Dairy
- Fortified plant milks (soy, oat, almond) - 120mg per 100ml
- Canned salmon with bones - 320mg per 100g
- Tahini - 106mg per 2 tablespoons
- Almonds - 23mg per 10 nuts
- Broccoli - 26mg per ½ cup cooked
- Chia seeds - 73mg per tablespoon

## Emergency Quick Options

### When Running Late (5-minute lunches)
- Peanut butter and jam on GF bread
- Bananas with nut butter
- Rice crackers with hummus and vegetables
- Pre-made smoothie from freezer
- Leftover pizza slice (check ingredients)

### School Canteen Safe Options
- Fresh fruit
- Rice crackers
- Nuts (if allowed)
- Water or juice
- Sushi (check ingredients for mayo/tempura)

## Troubleshooting Common Issues

### "My teenager won't eat vegetables"
- Hide vegetables in pasta sauces and soups
- Make vegetable chips (kale, sweet potato)
- Try different preparations (roasted vs raw)
- Include vegetables in smoothies

### "Gluten-free bread goes stale quickly"
- Store in freezer, toast from frozen
- Buy smaller loaves more frequently
- Use for breadcrumbs when stale
- Try different brands to find preferred texture

### "It's too expensive"
- Focus on whole foods over processed
- Buy generic brands where possible
- Cook from scratch more often
- Use seasonal vegetables and fruits

## Contact Information for Further Support

- **Dietitian referral**: Through family GP
- **Coeliac New Zealand**: For gluten-free resources
- **Allergy New Zealand**: For food allergy support
- **School nurse**: For managing dietary needs at school

---

*Remember: This is a guide to get you started. Every teenager is different, so adjust portions and foods based on your daughter's preferences, activity level, and growth needs. When in doubt, consult with a registered dietitian who can provide personalized advice.*